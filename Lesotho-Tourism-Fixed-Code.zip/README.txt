LESOTHO TOURISM — FIXED WEBSITE FILES

This pack fixes the paths and shared JavaScript/CSS for the seven-page website.

IMPORTANT:
- These are website CODE files only. Your existing JPG photographs are not included.
- Keep the existing JPG files in the root of your GitHub repository, alongside these files.
- Upload/replace these nine files in the ROOT of your repository (not inside css/ or js/ folders):
  index.html, about.html, destinations.html, accommodation.html, activities.html,
  gallery.html, contact.html, style.css, script.js
- After committing the files to the main branch, open:
  https://nicolas45548.github.io/lesotho-tourism-/
- If the site is cached, refresh the page or open it in a private/incognito tab.

The booking/contact forms are demonstrations only. They validate inputs and show a message in the browser; they do not send data to a real server.
