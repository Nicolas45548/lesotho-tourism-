"use strict";

function changeMode() {
  document.body.classList.toggle("dark-mode");
  try { localStorage.setItem("mode", document.body.classList.contains("dark-mode") ? "dark" : "light"); } catch (e) {}
}
try { if (localStorage.getItem("mode") === "dark") document.body.classList.add("dark-mode"); } catch (e) {}

function searchDestinations() {
  const inputEl = document.getElementById("search");
  if (!inputEl) return;
  const input = inputEl.value.toLowerCase().trim();
  document.querySelectorAll(".destination-card").forEach(card => {
    card.style.display = card.innerText.toLowerCase().includes(input) ? "" : "none";
  });
}

function filterActivities(category) {
  document.querySelectorAll(".activity-card").forEach(card => {
    card.style.display = category === "all" || card.classList.contains(category) ? "" : "none";
  });
}

function validateBooking() {
  const name = document.getElementById("name");
  const email = document.getElementById("email");
  const people = document.getElementById("people");
  const message = document.getElementById("bookingMessage");
  if (!name || !email || !people || !message) return false;
  if (!name.value.trim() || !email.value.trim() || Number(people.value) < 1) {
    message.textContent = "Please fill in all required fields correctly.";
    message.className = "alert alert-danger mt-3";
    return false;
  }
  try { localStorage.setItem("visitorName", name.value.trim()); } catch (e) {}
  message.textContent = "Booking details checked. This demo does not send the booking to a server.";
  message.className = "alert alert-success mt-3";
  return false;
}

function validateContact() {
  const name = document.getElementById("contactName");
  const email = document.getElementById("contactEmail");
  const messageInput = document.getElementById("contactMessage");
  const result = document.getElementById("contactResult");
  if (!name || !email || !messageInput || !result) return false;
  if (!name.value.trim() || !email.value.trim() || !messageInput.value.trim()) {
    result.textContent = "Please complete all required fields.";
    result.className = "alert alert-danger mt-3";
    return false;
  }
  result.textContent = "Thank you. Your message is validated, but this demo does not send it to a server.";
  result.className = "alert alert-success mt-3";
  return false;
}

function calculateCost() {
  const people = Number(document.getElementById("calcPeople")?.value);
  const days = Number(document.getElementById("calcDays")?.value);
  const result = document.getElementById("costResult");
  if (!result) return;
  if (!Number.isInteger(people) || !Number.isInteger(days) || people < 1 || days < 1) {
    result.textContent = "Enter a valid number of people and days (at least 1).";
    return;
  }
  result.textContent = "Estimated cost: M" + (people * days * 450).toLocaleString();
}

const galleryImages = ["maletsunyane.jpg", "katse-dam.jpg", "thaba-bosiu.jpg", "sehlabathebe.jpg"];
let currentImage = 0;
function showGalleryImage(index) {
  const main = document.getElementById("mainGallery");
  if (!main) return;
  currentImage = (index + galleryImages.length) % galleryImages.length;
  main.src = galleryImages[currentImage];
}
function nextImage() { showGalleryImage(currentImage + 1); }
function previousImage() { showGalleryImage(currentImage - 1); }
function setGalleryImage(img) {
  const main = document.getElementById("mainGallery");
  if (!main || !img) return;
  main.src = img.src;
  const file = img.getAttribute("src").split("/").pop();
  const index = galleryImages.indexOf(file);
  if (index >= 0) currentImage = index;
}
document.addEventListener("DOMContentLoaded", () => {
  let savedName = "";
  try { savedName = localStorage.getItem("visitorName") || ""; } catch (e) {}
  const welcome = document.getElementById("savedName");
  if (welcome && savedName) welcome.textContent = "Welcome back, " + savedName + "!";
});
