LESOTHO TOURISM WEBSITE — FIXED VERSION
======================================

This is your existing seven-page website, with the design and content preserved.

PAGES
-----
index.html
about.html
destinations.html
accommodation.html
activities.html
gallery.html
contact.html

FILES AND FOLDERS
-----------------
css/style.css
js/script.js
images/  (all JPG images used by the pages)

FIXES INCLUDED
--------------
- Corrected and checked local HTML, CSS, JavaScript, and image paths.
- Added the missing stylesheet link on activities.html.
- Fixed the gallery slideshow to use the JPG images included in images/.
- Loaded Bootstrap's JavaScript bundle so the mobile navigation menu can open.
- Improved form checks, search/filter controls, and mobile image sizing.
- Checked that every local file referenced by the HTML and CSS exists.

HOW TO PUT THIS ON GITHUB PAGES
-------------------------------
1. Download and extract this ZIP on your phone or computer.
2. Open your GitHub repository.
3. Upload the CONTENTS of the extracted folder (the seven HTML files, css folder,
   js folder, images folder, and README.txt) directly into the repository's root.
   Do not upload only the ZIP file or put everything inside an extra nested folder.
4. Commit the changes to the main branch.
5. In Settings > Pages, select Deploy from a branch, choose main and /(root),
   then save. If Pages is already enabled, wait for the new deployment.
6. Open the published Pages URL and refresh it.

NOTES
-----
- Bootstrap is loaded from a CDN, so an internet connection is needed for Bootstrap styling
  and the responsive navigation menu.
- The booking and contact forms display demo confirmations only; they do not send data
  to a server or actually submit reservations.
- Keep the images, css, and js folders in the same repository root as index.html.
