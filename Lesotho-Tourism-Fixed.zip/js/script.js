// Interactive features for the Lesotho Tourism website.

// Dark and light mode
function changeMode() {
    document.body.classList.toggle("dark-mode");
    try {
        localStorage.setItem(
            "mode",
            document.body.classList.contains("dark-mode") ? "dark" : "light"
        );
    } catch (error) {
        // The website still works if browser storage is unavailable.
    }
}

try {
    if (localStorage.getItem("mode") === "dark") {
        document.body.classList.add("dark-mode");
    }
} catch (error) {
    // Ignore storage restrictions.
}

// Search destinations
function searchDestinations() {
    const searchBox = document.getElementById("search");
    if (!searchBox) return;

    const input = searchBox.value.trim().toLowerCase();
    const cards = document.getElementsByClassName("destination-card");

    for (let i = 0; i < cards.length; i++) {
        const text = (cards[i].innerText || cards[i].textContent || "").toLowerCase();
        cards[i].style.display = text.includes(input) ? "" : "none";
    }
}

// Filter activities
function filterActivities(category) {
    const cards = document.getElementsByClassName("activity-card");

    for (let i = 0; i < cards.length; i++) {
        cards[i].style.display =
            category === "all" || cards[i].classList.contains(category) ? "" : "none";
    }
}

// Booking form validation (demo only; does not send information to a server)
function validateBooking() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const people = document.getElementById("people");
    const result = document.getElementById("bookingMessage");

    if (!name || !email || !people || !result) return false;

    if (!name.value.trim() || !email.value.trim() || Number(people.value) < 1) {
        result.textContent = "Please fill in your name, a valid email address, and number of people.";
        result.className = "alert alert-danger mt-3";
        return false;
    }

    try {
        localStorage.setItem("visitorName", name.value.trim());
    } catch (error) {
        // Form confirmation still works without storage.
    }
    result.textContent = "Your booking request has been checked. This demo website does not send bookings to a server.";
    result.className = "alert alert-success mt-3";
    return false;
}

// Contact form validation (demo only; does not send information to a server)
function validateContact() {
    const name = document.getElementById("contactName");
    const email = document.getElementById("contactEmail");
    const message = document.getElementById("contactMessage");
    const result = document.getElementById("contactResult");

    if (!name || !email || !message || !result) return false;

    if (!name.value.trim() || !email.value.trim() || !message.value.trim()) {
        result.textContent = "Please complete all required fields.";
        result.className = "alert alert-danger mt-3";
        return false;
    }

    result.textContent = "Thank you! Your message has been checked. This demo website does not send messages to a server.";
    result.className = "alert alert-success mt-3";
    return false;
}

// Booking cost calculator
function calculateCost() {
    const peopleInput = document.getElementById("calcPeople");
    const daysInput = document.getElementById("calcDays");
    const result = document.getElementById("costResult");
    if (!peopleInput || !daysInput || !result) return;

    const people = Number(peopleInput.value);
    const days = Number(daysInput.value);

    if (!Number.isFinite(people) || !Number.isFinite(days) || people < 1 || days < 1) {
        result.textContent = "Enter valid numbers of people and days.";
        return;
    }

    result.textContent = "Estimated cost: M" + (people * days * 450).toLocaleString();
}

// Gallery next/previous controls
const galleryImages = [
    "images/maletsunyane.jpg",
    "images/katse-dam.jpg",
    "images/thaba-bosiu.jpg",
    "images/sehlabathebe.jpg"
];
let currentImage = 0;

function setGalleryImage(index) {
    const image = document.getElementById("mainGallery");
    if (!image) return;
    currentImage = (index + galleryImages.length) % galleryImages.length;
    image.src = galleryImages[currentImage];
}

function nextImage() {
    setGalleryImage(currentImage + 1);
}

function previousImage() {
    setGalleryImage(currentImage - 1);
}

// Show saved visitor name when a matching element exists
window.addEventListener("load", function () {
    let savedName = null;
    try {
        savedName = localStorage.getItem("visitorName");
    } catch (error) {
        // Ignore storage restrictions.
    }

    const welcome = document.getElementById("savedName");
    if (savedName && welcome) {
        welcome.textContent = "Welcome back, " + savedName + "!";
    }
});
